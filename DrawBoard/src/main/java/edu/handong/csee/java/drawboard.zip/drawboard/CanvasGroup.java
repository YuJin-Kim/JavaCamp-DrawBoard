package edu.handong.csee.java.drawboard;

import javax.swing.JTabbedPane;

public class CanvasGroup extends JTabbedPane{
	
	CanvasGroup() {
	}
}
